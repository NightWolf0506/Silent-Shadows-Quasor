// Add this line at the top of the file to mark the component as a Client Component
"use client";

import { Calendar, momentLocalizer, View, Views } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { useState } from "react";

// Sample calendar events with role-based titles
// Sample calendar events with role-based titles
export const calendarEvents = [
  {
    title: "Math Exam Room:A201",
    start: new Date(2025, 2, 10, 8, 0), // March 10, 2025, 9:00 AM
    end: new Date(2025, 2, 10, 10, 0),  // March 10, 2025, 12:00 PM
    role: "student",
  },
  {
    title: "Physics Exam Room:A301",
    start: new Date(2025, 2, 11, 9, 0),
    end: new Date(2025, 2, 11, 12, 0),
    role: "teacher",
  },
  {
    title: "History Exam Room:A401",
    start: new Date(2025, 2, 12, 9, 0),
    end: new Date(2025, 2, 12, 14, 0),
    role: "student",
  },
  {
    title: "Biology Exam Duty Room:A201",
    start: new Date(2025, 2, 13, 11, 0),
    end: new Date(2025, 2, 13, 113, 0),
    role: "teacher",
  },
];


// Initialize the localizer
const localizer = momentLocalizer(moment);

const BigCalendar = () => {
  const [view, setView] = useState<View>(Views.WORK_WEEK);

  const handleOnChangeView = (selectedView: View) => {
    setView(selectedView);
  };

  // Modify the calendar events based on the role (teacher/student)
  const modifiedEvents = calendarEvents.map((event) => {
    if (event.role === "teacher") {
      return {
        ...event,
        title: `Exam Duty: ${event.title}`,
      };
    } else if (event.role === "student") {
      return {
        ...event,
        title: `Exam Date: ${event.title}`,
      };
    }
    return event;
  });

  // Log the modified events to make sure they are correctly processed
  console.log(modifiedEvents);

  return (
    <Calendar
      localizer={localizer}
      events={modifiedEvents}
      startAccessor="start"
      endAccessor="end"
      views={["work_week", "day"]}
      view={view}
      style={{ height: "98%" }}
      onView={handleOnChangeView}
      min={new Date(2025, 3, 19, 8, 0)} // Start of work week (April 19, 2025, 8:00 AM)
      max={new Date(2025, 3, 24, 17, 0)} // End of work week (April 24, 2025, 5:00 PM)
      eventPropGetter={(event) => ({
        style: {
          backgroundColor: event.role === "teacher" ? "#FF6347" : "#4CAF50", // Different colors for teacher and student events
          color: "white",
          borderRadius: "5px",
        },
      })}
    />
  );
};

export default BigCalendar;
