"use client";

import * as Clerk from "@clerk/elements/common";
import * as SignIn from "@clerk/elements/sign-in";
import { useUser } from "@clerk/nextjs";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { setRole } from "@/lib/data"; // Import setRole

const LoginPage = () => {
  const { isLoaded, isSignedIn, user } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (isLoaded && isSignedIn && user) {
      const role = (user?.publicMetadata?.role as "admin"| "teacher" | "parent" | "student" || "student");
      
      setRole(role); // ✅ Update role dynamically
      router.replace(`/${role}`); // ✅ Redirect user based on role
    }
  }, [isLoaded, isSignedIn, user, router]);

  return (
    <div className="h-screen flex items-center justify-center animated-bg">
      <SignIn.Root>
        <SignIn.Step
          name="start"
          className="bg-white p-12 rounded-md shadow-2xl flex flex-col gap-2 border border-gray-200"
        >
          {/* Logo & Title */}
          <h1 className="text-3xl font-bold flex items-center gap-2 place-content-center text-yellow-600">
            <Image src="/logo.png" alt="Logo" width={24} height={24} />
            MU Hub
          </h1>
          <h2 className="text-yellow-500 text-center">Sign in to your account</h2>

          {/* Error Message */}
          <Clerk.GlobalError className="text-sm text-red-500" />

          {/* Username Field */}
          <Clerk.Field name="identifier" className="flex flex-col gap-2">
            <Clerk.Label className="text-xs text-yellow-700">Username</Clerk.Label>
            <Clerk.Input
              type="text"
              required
              className="p-2 rounded-md border border-yellow-300 bg-yellow-50 text-yellow-800 focus:ring-2 focus:ring-yellow-400"
            />
            <Clerk.FieldError className="text-xs text-red-500" />
          </Clerk.Field>

          {/* Password Field */}
          <Clerk.Field name="password" className="flex flex-col gap-2">
            <Clerk.Label className="text-xs text-yellow-700">Password</Clerk.Label>
            <Clerk.Input
              type="password"
              required
              className="p-2 rounded-md border border-yellow-300 bg-yellow-50 text-yellow-800 focus:ring-2 focus:ring-yellow-400"
            />
            <Clerk.FieldError className="text-xs text-red-500" />
          </Clerk.Field>

          {/* Sign-In Button */}
          <SignIn.Action
            submit
            className="bg-yellow-500 text-white my-1 rounded-md text-sm p-[10px] hover:bg-yellow-600 transition-all"
          >
            Sign In
          </SignIn.Action>
        </SignIn.Step>
      </SignIn.Root>
    </div>
  );
};

export default LoginPage;
