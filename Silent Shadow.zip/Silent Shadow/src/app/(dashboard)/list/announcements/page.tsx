"use client";

import { useUser } from "@clerk/nextjs";
import Pagination from "@/components/Pagination";
import Table from "@/components/Table";
import TableSearch from "@/components/TableSearch";
import { useState, useEffect } from "react";

type ExamAnnouncement = {
  id: number;
  title: string;
  subject: string;
  examDate: string;
};

const initialAnnouncements: ExamAnnouncement[] = [
  { id: 1, title: "Mid-Term Exams", subject: "Mathematics", examDate: "2025-04-10" },
  { id: 2, title: "Final Exams", subject: "Physics", examDate: "2025-06-15" },
];

const columns = [
  { header: "Title", accessor: "title" },
  { header: "Subject", accessor: "subject" },
  { header: "Exam Date", accessor: "examDate", className: "hidden md:table-cell" },
  { header: "Actions", accessor: "action" },
];

const ExamAnnouncementPage = () => {
  const { isLoaded, isSignedIn, user } = useUser();
  const [userRole, setUserRole] = useState<string>("user");
  const [announcements, setAnnouncements] = useState<ExamAnnouncement[]>(initialAnnouncements);
  const [showForm, setShowForm] = useState(false);
  const [formType, setFormType] = useState<"create" | "update" | "delete" | null>(null);
  const [currentAnnouncement, setCurrentAnnouncement] = useState<ExamAnnouncement | null>(null);

  useEffect(() => {
    if (isLoaded && isSignedIn && user) {
      const role = (user?.publicMetadata?.role as string) || "user";
      setUserRole(role);
    }
  }, [isLoaded, isSignedIn, user]);

  const handleFormSubmit = (event: React.FormEvent) => {
    event.preventDefault();

    if (formType === "create" && currentAnnouncement) {
      // Generate a new ID for the new announcement (you might want to replace this with a more robust approach)
      const newId = announcements.length > 0 ? Math.max(...announcements.map(a => a.id)) + 1 : 1;
      setAnnouncements([...announcements, { ...currentAnnouncement, id: newId }]);
    } else if (formType === "update" && currentAnnouncement) {
      setAnnouncements(
        announcements.map((a) => (a.id === currentAnnouncement.id ? currentAnnouncement : a))
      );
    } else if (formType === "delete" && currentAnnouncement) {
      setAnnouncements(announcements.filter((a) => a.id !== currentAnnouncement.id));
    }

    // Reset form state after submission
    setShowForm(false);
    setCurrentAnnouncement(null);
    setFormType(null);
  };

  const renderRow = (item: ExamAnnouncement) => (
    <tr key={item.id} className="border-b border-gray-200 even:bg-slate-50 text-sm hover:bg-gray-100">
      <td className="p-4">{item.title}</td>
      <td>{item.subject}</td>
      <td className="hidden md:table-cell">{item.examDate}</td>
      <td>
        <div className="flex items-center gap-2">
          {userRole === "admin" && (
            <>
              <button
                className="text-blue-500"
                onClick={() => {
                  setFormType("update");
                  setCurrentAnnouncement(item);
                  setShowForm(true);
                }}
              >
                Edit
              </button>
              <button
                className="text-red-500"
                onClick={() => {
                  setFormType("delete");
                  setCurrentAnnouncement(item);
                  setShowForm(true);
                }}
              >
                Delete
              </button>
            </>
          )}
        </div>
      </td>
    </tr>
  );

  return (
    <div className="bg-white p-4 rounded-md flex-1 m-4 mt-0">
      {/* TOP SECTION */}
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Exam Announcements</h1>
        {userRole === "admin" && (
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded-md"
            onClick={() => {
              setFormType("create");
              setCurrentAnnouncement({ id: 0, title: "", subject: "", examDate: "" });
              setShowForm(true);
            }}
          >
            + Add Announcement
          </button>
        )}
      </div>

      {/* LIST */}
      <Table columns={columns} renderRow={renderRow} data={announcements} />
      <Pagination />

      {/* FORM MODAL */}
      {showForm && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50">
          <div className="bg-white p-6 rounded-md w-96">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">
                {formType === "create"
                  ? "Create Exam Announcement"
                  : formType === "update"
                  ? "Update Exam Announcement"
                  : "Delete Exam Announcement"}
              </h2>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                ✖
              </button>
            </div>
            {formType !== "delete" ? (
              <form onSubmit={handleFormSubmit} className="flex flex-col gap-4">
                <input
                  type="text"
                  placeholder="Title"
                  value={currentAnnouncement?.title || ""}
                  onChange={(e) =>
                    setCurrentAnnouncement((prev) => (prev ? { ...prev, title: e.target.value } : null))
                  }
                  className="border p-2 rounded-md"
                  required
                />
                <input
                  type="text"
                  placeholder="Subject"
                  value={currentAnnouncement?.subject || ""}
                  onChange={(e) =>
                    setCurrentAnnouncement((prev) => (prev ? { ...prev, subject: e.target.value } : null))
                  }
                  className="border p-2 rounded-md"
                  required
                />
                <input
                  type="date"
                  value={currentAnnouncement?.examDate || ""}
                  onChange={(e) =>
                    setCurrentAnnouncement((prev) => (prev ? { ...prev, examDate: e.target.value } : null))
                  }
                  className="border p-2 rounded-md"
                  required
                />
                <button type="submit" className="bg-green-500 text-white px-4 py-2 rounded-md">
                  {formType === "create" ? "Create" : "Update"}
                </button>
              </form>
            ) : (
              <>
                <p>Are you sure you want to delete this exam announcement?</p>
                <div className="flex gap-4 mt-4">
                  <button onClick={handleFormSubmit} className="bg-red-500 text-white px-4 py-2 rounded-md">
                    Delete
                  </button>
                  <button onClick={() => setShowForm(false)} className="bg-gray-300 px-4 py-2 rounded-md">
                    Cancel
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ExamAnnouncementPage;
